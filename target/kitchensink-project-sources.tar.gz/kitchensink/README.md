# samplemaven
This is a sample maven project that produces a web application (war file)
